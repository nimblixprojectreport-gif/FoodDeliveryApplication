import { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { auth } from '../api';

/* ────────── AUTH ────────── */
const AuthCtx = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser]       = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem('qb_user');
    const token  = localStorage.getItem('qb_token');
    if (stored && token) setUser(JSON.parse(stored));
    setLoading(false);
  }, []);

  const login = useCallback(async (username, password) => {
    // Django LoginView reads request.data.get("mobile") then authenticate(username=mobile)
    // So field name sent must be "mobile", value = the username
    const data = await auth.login({ mobile: username, password });
    if (!data.token) throw { data: { error: 'No token returned. Add TokenAuthentication to Django REST_FRAMEWORK settings.' } };
    localStorage.setItem('qb_token', data.token);
    const profile = await auth.profile();
    localStorage.setItem('qb_user', JSON.stringify(profile));
    setUser(profile);
    return profile;
  }, []);

  const register = useCallback(async (body) => {
    await auth.register(body);
    return login(body.username, body.password);
  }, [login]);

  const logout = useCallback(async () => {
    try { await auth.logout(); } catch {}
    localStorage.removeItem('qb_token');
    localStorage.removeItem('qb_user');
    setUser(null);
  }, []);

  return (
    <AuthCtx.Provider value={{ user, loading, login, register, logout, isLoggedIn: !!user }}>
      {children}
    </AuthCtx.Provider>
  );
}

export const useAuth = () => useContext(AuthCtx);

/* ────────── TOAST ────────── */
const ToastCtx = createContext(null);

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const toast = useCallback((message, type = 'info') => {
    const id = Date.now();
    setToasts(p => [...p, { id, message, type }]);
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 3500);
  }, []);

  return (
    <ToastCtx.Provider value={toast}>
      {children}
      {toasts.length > 0 && (
        <div className="toast-wrap">
          {toasts.map(t => (
            <div key={t.id} className={`toast toast-${t.type}`}>
              <span>{t.type==='success'?'✅':t.type==='error'?'❌':'ℹ️'}</span>
              {t.message}
            </div>
          ))}
        </div>
      )}
    </ToastCtx.Provider>
  );
}

export const useToast = () => useContext(ToastCtx);
