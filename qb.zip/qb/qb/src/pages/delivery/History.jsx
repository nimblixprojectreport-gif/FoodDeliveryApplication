import { useState, useEffect } from 'react';
import { useToast } from '../../context/index.jsx';

export default function DeliveryHistory() {
  const toast = useToast();
  const [orders, setOrders]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [fetchErr, setFetchErr] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('qb_token');
    fetch('/api/v1/delivery/status/', {
      headers: { Authorization: `Token ${token}` },
    })
      .then(res => {
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res.json();
      })
      .then(data => {
        setOrders(Array.isArray(data) ? data : []);
      })
      .catch(err => {
        setFetchErr(err.message);
        toast('Could not load history', 'error');
      })
      .finally(() => setLoading(false));
  }, []);

  const completed = orders.filter(o => o.status === 'DELIVERED');
  const active    = orders.filter(o => o.status !== 'DELIVERED');
  const earnings  = completed.length * 40;

  // Use DM Sans (body font) for numbers — Syne font makes 0 look like an oval
  const numStyle = {
    fontFamily: "'DM Sans', sans-serif",
    fontSize: 42,
    fontWeight: 800,
    lineHeight: 1,
  };

  const STATUS_BADGE = {
    PICKED_UP:        { bg:'rgba(139,92,246,.15)', color:'#8b5cf6', text:'Picked Up' },
    OUT_FOR_DELIVERY: { bg:'rgba(249,115,22,.15)',  color:'#f97316', text:'Out for Delivery' },
    DELIVERED:        { bg:'rgba(34,197,94,.15)',   color:'#22c55e', text:'Delivered' },
  };

  if (loading) return (
    <div className="loading-wrap">
      <div className="spinner" />
      <span style={{ marginLeft:12, color:'var(--muted)' }}>Loading history…</span>
    </div>
  );

  return (
    <div className="page fade-in">
      <h1 className="page-title">📋 Delivery History</h1>

      {/* Error banner if Django views.py not replaced yet */}
      {fetchErr && (
        <div style={{ background:'rgba(239,68,68,.1)', border:'1px solid rgba(239,68,68,.3)', borderRadius:'var(--r-md)', padding:'12px 16px', marginBottom:20, fontSize:13, color:'#ef4444', lineHeight:1.6 }}>
          ⚠️ <strong>API Error ({fetchErr}):</strong> Replace <code>delivery/views.py</code> in your Django project with the file from the zip, then restart Django with <code>Ctrl+C → python manage.py runserver</code>
        </div>
      )}

      {/* Stats — DM Sans font so 0 shows as digit not oval */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:16, marginBottom:28 }}>
        <div className="card" style={{ textAlign:'center', padding:'24px 12px' }}>
          <div style={{ ...numStyle, color:'var(--teal)' }}>{orders.length}</div>
          <div style={{ color:'var(--muted)', fontSize:13, marginTop:10, fontWeight:500 }}>Total Deliveries</div>
        </div>
        <div className="card" style={{ textAlign:'center', padding:'24px 12px' }}>
          <div style={{ ...numStyle, color:'var(--green)' }}>{completed.length}</div>
          <div style={{ color:'var(--muted)', fontSize:13, marginTop:10, fontWeight:500 }}>Completed</div>
        </div>
        <div className="card" style={{ textAlign:'center', padding:'24px 12px' }}>
          <div style={{ ...numStyle, color:'var(--accent)' }}>&#8377;{earnings}</div>
          <div style={{ color:'var(--muted)', fontSize:13, marginTop:10, fontWeight:500 }}>Est. Earnings</div>
        </div>
      </div>

      {orders.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">📋</div>
          <h3>No deliveries yet</h3>
          <p>Accept and complete orders from the Dashboard — they will appear here</p>
        </div>
      ) : (
        <>
          {active.length > 0 && (
            <>
              <h2 className="section-title" style={{ marginBottom:14 }}>🔄 Active ({active.length})</h2>
              <div style={{ display:'flex', flexDirection:'column', gap:12, marginBottom:28 }}>
                {active.map(order => renderCard(order, STATUS_BADGE))}
              </div>
            </>
          )}
          {completed.length > 0 && (
            <>
              <h2 className="section-title" style={{ marginBottom:14 }}>✅ Completed ({completed.length})</h2>
              <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
                {completed.map(order => renderCard(order, STATUS_BADGE))}
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}

function renderCard(order, STATUS_BADGE) {
  const sc = STATUS_BADGE[order.status] || { bg:'rgba(6,182,212,.15)', color:'var(--teal)', text: order.status };
  return (
    <div key={order.id} className="card" style={{ padding:'16px 20px' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', flexWrap:'wrap', gap:12, marginBottom: order.items?.length ? 10 : 0 }}>
        <div>
          <div style={{ fontFamily:"'DM Sans', sans-serif", fontWeight:700, fontSize:16 }}>Order #{order.id}</div>
          <div style={{ color:'var(--muted)', fontSize:13, marginTop:3 }}>
            {new Date(order.created_at).toLocaleString('en-IN', { day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit' })}
          </div>
          <div style={{ color:'var(--muted)', fontSize:13 }}>📍 {order.delivery_address}</div>
          <div style={{ color:'var(--accent)', fontWeight:700, marginTop:4 }}>&#8377;{order.total_amount}</div>
        </div>
        <span style={{ padding:'5px 14px', borderRadius:20, fontSize:12, fontWeight:700, background:sc.bg, color:sc.color, border:`1px solid ${sc.color}33` }}>
          {sc.text}
        </span>
      </div>
      {order.items?.length > 0 && (
        <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>
          {order.items.map((it,i) => (
            <span key={i} style={{ padding:'2px 10px', background:'var(--navy2)', border:'1px solid var(--border)', borderRadius:20, fontSize:12, color:'var(--text2)' }}>
              {it.quantity}× {it.menu_item_name}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
