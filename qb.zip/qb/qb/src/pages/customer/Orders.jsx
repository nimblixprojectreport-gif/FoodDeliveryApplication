import { useState, useEffect } from 'react';
import { orders as ordersAPI, reviews as reviewsAPI } from '../../api';
import { useToast } from '../../context/index.jsx';

const STATUS_STEPS = ['PENDING','PREPARING','PICKED_UP','OUT_FOR_DELIVERY','DELIVERED'];

const STATUS_LABEL = {
  PENDING:'Order Placed', PREPARING:'Being Prepared', PICKED_UP:'Picked Up',
  OUT_FOR_DELIVERY:'Out for Delivery', DELIVERED:'Delivered', CANCELLED:'Cancelled',
};

export default function MyOrders() {
  const toast = useToast();
  const [list, setList]       = useState([]);
  const [loading, setLoading] = useState(true);
  const [reviewModal, setReviewModal] = useState(null); // order object
  const [reviewForm, setReviewForm]   = useState({ rating:5, comment:'' });
  const [tab, setTab]         = useState('active');

  const load = () => {
    setLoading(true);
    ordersAPI.list()
      .then(setList)
      .catch(() => toast('Could not load orders', 'error'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const cancelOrder = async (id) => {
    if (!confirm('Cancel this order?')) return;
    try {
      await ordersAPI.cancel(id);
      toast('Order cancelled', 'info');
      load();
    } catch (err) {
      toast(err?.data?.error || 'Cannot cancel', 'error');
    }
  };

  const submitReview = async () => {
    try {
      await reviewsAPI.create({ order_id: reviewModal.id, rating: reviewForm.rating, comment: reviewForm.comment });
      toast('Review submitted! ⭐', 'success');
      setReviewModal(null);
    } catch (err) {
      toast(err?.data?.error || 'Could not submit review', 'error');
    }
  };

  const active = list.filter(o => !['DELIVERED','CANCELLED'].includes(o.status));
  const past   = list.filter(o =>  ['DELIVERED','CANCELLED'].includes(o.status));
  const shown  = tab === 'active' ? active : past;

  return (
    <div className="page fade-in">
      <h1 className="page-title">📦 My Orders</h1>

      {/* Tabs */}
      <div style={s.tabs}>
        {[['active','🔥 Active'], ['past','📦 Past']].map(([k, label]) => (
          <button key={k} style={{ ...s.tab, ...(tab===k ? s.tabActive : {}) }} onClick={() => setTab(k)}>
            {label}
            {k==='active' && active.length > 0 && <span style={s.badge}>{active.length}</span>}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="loading-wrap"><div className="spinner" /></div>
      ) : shown.length === 0 ? (
        <div className="empty-state"><div className="empty-icon">📭</div><h3>No {tab} orders</h3></div>
      ) : (
        <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
          {shown.map(order => (
            <div key={order.id} className="card fade-in" style={{ padding:'22px 24px' }}>
              <div style={s.orderHead}>
                <div>
                  <div style={{ fontFamily:'var(--display)', fontWeight:700, fontSize:16 }}>Order #{order.id}</div>
                  <div style={{ color:'var(--muted)', fontSize:13, marginTop:3 }}>
                    {new Date(order.created_at).toLocaleString('en-IN')} · ₹{order.total_amount}
                  </div>
                </div>
                <span className={`badge status-${order.status}`} style={{ padding:'5px 14px', borderRadius:20, fontSize:12, fontWeight:700 }}>
                  {STATUS_LABEL[order.status] || order.status}
                </span>
              </div>

              {/* Progress bar */}
              {!['CANCELLED'].includes(order.status) && (
                <div style={s.progress}>
                  {STATUS_STEPS.map((step, i) => {
                    const idx = STATUS_STEPS.indexOf(order.status);
                    const allDone = order.status === 'DELIVERED';
                    const done   = allDone || i < idx;
                    const active = !allDone && i === idx;
                    return (
                      <div key={step} style={s.step}>
                        {i > 0 && <div style={{ ...s.line, background: done ? 'var(--green)' : 'var(--border)' }} />}
                        <div style={{ ...s.dot, background: done ? 'var(--green)' : active ? 'var(--accent)' : 'var(--surface2)', border: `2px solid ${done ? 'var(--green)' : active ? 'var(--accent)' : 'var(--border)'}`, boxShadow: active ? '0 0 10px var(--accent)' : 'none', zIndex:1 }}>
                          {done ? '✓' : ''}
                        </div>
                        <span style={{ fontSize:10, color: active ? 'var(--accent)' : 'var(--muted)', textAlign:'center', fontWeight: active ? 700 : 400 }}>
                          {STATUS_LABEL[step]?.split(' ')[0]}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Items */}
              <div style={{ display:'flex', flexWrap:'wrap', gap:6, margin:'12px 0' }}>
                {order.items?.map((it, i) => (
                  <span key={i} style={s.itemChip}>{it.quantity}× {it.menu_item_name} (₹{it.price})</span>
                ))}
              </div>

              <div style={s.orderAddr}>📍 {order.delivery_address}</div>

              {/* Actions */}
              <div style={{ display:'flex', gap:8, marginTop:14, flexWrap:'wrap' }}>
                {order.status === 'PENDING' && (
                  <button className="btn btn-danger btn-sm" onClick={() => cancelOrder(order.id)}>Cancel Order</button>
                )}
                {order.status === 'DELIVERED' && !order.review && (
                  <button className="btn btn-success btn-sm" onClick={() => { setReviewModal(order); setReviewForm({ rating:5, comment:'' }); }}>⭐ Rate & Review</button>
                )}
                {order.status === 'DELIVERED' && order.review && (
                  <span className="badge badge-green">✅ Reviewed</span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Review Modal */}
      {reviewModal && (
        <div style={modal.overlay} onClick={() => setReviewModal(null)}>
          <div style={modal.box} onClick={e => e.stopPropagation()}>
            <h3 style={{ fontFamily:'var(--display)', fontWeight:700, marginBottom:16 }}>Rate Order #{reviewModal.id}</h3>
            <div className="form-group">
              <label className="form-label">Rating</label>
              <select className="form-input" value={reviewForm.rating} onChange={e => setReviewForm(f => ({...f, rating: parseInt(e.target.value)}))}>
                {[5,4,3,2,1].map(n => <option key={n} value={n}>{n} ⭐</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Comment (optional)</label>
              <textarea className="form-input" rows={3} value={reviewForm.comment} onChange={e => setReviewForm(f => ({...f, comment:e.target.value}))} placeholder="How was the food?" />
            </div>
            <div style={{ display:'flex', gap:10 }}>
              <button className="btn btn-primary" onClick={submitReview}>Submit Review</button>
              <button className="btn btn-secondary" onClick={() => setReviewModal(null)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const s = {
  tabs: { display:'flex', gap:4, background:'var(--surface)', borderRadius:'var(--r-md)', padding:4, width:'fit-content', marginBottom:24 },
  tab: { padding:'8px 20px', borderRadius:'var(--r-sm)', fontSize:14, fontWeight:600, color:'var(--muted)', display:'flex', alignItems:'center', gap:8, border:'none', cursor:'pointer', background:'none' },
  tabActive: { background:'var(--navy2)', color:'var(--text)' },
  badge: { background:'var(--accent)', color:'white', borderRadius:'50%', width:18, height:18, display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize:10, fontWeight:700 },
  orderHead: { display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:16, gap:12 },
  progress: { display:'flex', alignItems:'flex-start', margin:'16px 0', position:'relative' },
  step: { flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap:5, position:'relative' },
  line: { position:'absolute', top:10, right:'50%', width:'100%', height:2, zIndex:0 },
  dot: { width:22, height:22, borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', fontSize:10, color:'white', position:'relative' },
  itemChip: { padding:'3px 10px', background:'var(--navy2)', border:'1px solid var(--border)', borderRadius:20, fontSize:12, color:'var(--text2)' },
  orderAddr: { fontSize:13, color:'var(--muted)' },
};
const modal = {
  overlay: { position:'fixed', inset:0, background:'rgba(0,0,0,.7)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:999, padding:20 },
  box: { background:'var(--surface)', border:'1px solid var(--border)', borderRadius:'var(--r-xl)', padding:28, width:420, maxWidth:'100%' },
};
