import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { restaurants as rAPI, cart as cartAPI, orders as ordersAPI } from '../../api';
import { useToast } from '../../context/index.jsx';

export default function RestaurantDetail() {
  const { id } = useParams();
  const nav    = useNavigate();
  const toast  = useToast();

  const [restaurant, setRestaurant] = useState(null);
  const [menuItems, setMenuItems]   = useState([]);
  const [serverCart, setServerCart] = useState(null); // from backend
  const [localQty, setLocalQty]     = useState({});   // { menu_item_id: qty }
  const [loading, setLoading]       = useState(true);
  const [cartLoading, setCartLoading] = useState(false);
  const [address, setAddress]       = useState('');
  const [placing, setPlacing]       = useState(false);

  useEffect(() => {
    Promise.all([
      rAPI.detail(id),
      rAPI.menu(id).catch(() => null),
      cartAPI.get().catch(() => null),
    ]).then(([rest, menu, c]) => {
      setRestaurant(rest);
      setMenuItems(menu?.items || rest?.menu?.items || []);
      if (c) {
        setServerCart(c);
        const qty = {};
        c.items.forEach(ci => { qty[ci.menu_item.id] = ci.quantity; });
        setLocalQty(qty);
      }
    }).finally(() => setLoading(false));
  }, [id]);

  const refreshCart = async () => {
    const c = await cartAPI.get().catch(() => null);
    if (c) {
      setServerCart(c);
      const qty = {};
      c.items.forEach(ci => { qty[ci.menu_item.id] = ci.quantity; });
      setLocalQty(qty);
    }
  };

  const addToCart = async (item) => {
    setCartLoading(true);
    try {
      await cartAPI.addItem(item.id, 1);
      setLocalQty(q => ({ ...q, [item.id]: (q[item.id] || 0) + 1 }));
      await refreshCart();
      toast(`${item.name} added!`, 'success');
    } catch (err) {
      toast(err?.data?.error || 'Could not add item', 'error');
    } finally { setCartLoading(false); }
  };

  const removeFromCart = async (itemId) => {
    if (!serverCart) return;
    const ci = serverCart.items.find(ci => ci.menu_item.id === itemId);
    if (!ci) return;
    setCartLoading(true);
    try {
      await cartAPI.removeItem(ci.id);
      setLocalQty(q => {
        const n = { ...q };
        if (n[itemId] > 1) n[itemId]--; else delete n[itemId];
        return n;
      });
      await refreshCart();
    } catch {} finally { setCartLoading(false); }
  };

  const placeOrder = async () => {
    if (!address.trim()) { toast('Enter delivery address', 'error'); return; }
    setPlacing(true);
    try {
      await ordersAPI.checkout(address.trim());
      toast('Order placed successfully! 🎉', 'success');
      nav('/orders');
    } catch (err) {
      toast(err?.data?.error || 'Checkout failed', 'error');
    } finally { setPlacing(false); }
  };

  if (loading) return <div className="loading-wrap"><div className="spinner" /></div>;
  if (!restaurant) return <div className="page"><p>Restaurant not found.</p></div>;

  const cartItems = serverCart?.items || [];
  const total     = parseFloat(serverCart?.total_price || 0);
  const itemCount = cartItems.reduce((s, ci) => s + ci.quantity, 0);

  // Group by veg/non-veg
  const vegItems    = menuItems.filter(i => i.is_veg && i.is_available);
  const nonVegItems = menuItems.filter(i => !i.is_veg && i.is_available);
  const unavailable = menuItems.filter(i => !i.is_available);

  return (
    <div className="page fade-in">
      <button className="btn btn-secondary btn-sm" onClick={() => nav('/')} style={{ marginBottom:20 }}>← Back</button>

      {/* Restaurant header */}
      <div style={s.header}>
        <div style={s.headerBg} />
        <div style={{ position:'relative', zIndex:1 }}>
          <h1 style={{ fontFamily:'var(--display)', fontSize:32, fontWeight:800, marginBottom:8 }}>{restaurant.name}</h1>
          <p style={{ color:'var(--muted)', fontSize:14, marginBottom:10 }}>📍 {restaurant.address}</p>
          <p style={{ color:'var(--muted)', fontSize:14, marginBottom:12 }}>📞 {restaurant.contact_number}</p>
          <span className={`badge ${restaurant.is_approved ? 'badge-green' : 'badge-red'}`}>
            {restaurant.is_approved ? '✅ Approved & Open' : '⏳ Pending Approval'}
          </span>
        </div>
      </div>

      {menuItems.length === 0 ? (
        <div className="empty-state"><div className="empty-icon">📋</div><h3>No menu items yet</h3></div>
      ) : (
        <div style={{ display:'grid', gridTemplateColumns:'1fr 360px', gap:24, alignItems:'start' }}>
          {/* Menu */}
          <div>
            {vegItems.length > 0 && <MenuSection title="🌿 Veg Items" items={vegItems} localQty={localQty} onAdd={addToCart} onRemove={removeFromCart} busy={cartLoading} />}
            {nonVegItems.length > 0 && <MenuSection title="🍖 Non-Veg Items" items={nonVegItems} localQty={localQty} onAdd={addToCart} onRemove={removeFromCart} busy={cartLoading} />}
            {unavailable.length > 0 && <MenuSection title="❌ Currently Unavailable" items={unavailable} localQty={{}} onAdd={() => {}} onRemove={() => {}} busy={false} disabled />}
          </div>

          {/* Cart */}
          <div style={s.cartPanel}>
            <h3 style={{ fontFamily:'var(--display)', fontSize:18, fontWeight:700, marginBottom:16 }}>🛒 Your Cart</h3>
            {cartItems.length === 0 ? (
              <div style={{ textAlign:'center', padding:'30px 0', color:'var(--muted)' }}>
                <div style={{ fontSize:40, marginBottom:10 }}>🛒</div>
                <p>Cart is empty</p>
                <p style={{ fontSize:13, marginTop:4 }}>Add items from the menu</p>
              </div>
            ) : (
              <>
                <div style={{ display:'flex', flexDirection:'column', gap:10, marginBottom:14 }}>
                  {cartItems.map(ci => (
                    <div key={ci.id} style={s.cartRow}>
                      <span style={s.cartName}>{ci.menu_item.name}</span>
                      <div style={s.qtyCtrl}>
                        <button style={s.qtyBtn} onClick={() => removeFromCart(ci.menu_item.id)}>−</button>
                        <span style={{ fontWeight:700, minWidth:20, textAlign:'center' }}>{ci.quantity}</span>
                        <button style={s.qtyBtn} onClick={() => addToCart(ci.menu_item)}>+</button>
                      </div>
                      <span style={{ fontWeight:700, color:'var(--accent)', fontSize:13 }}>₹{(ci.menu_item.price * ci.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
                <div className="divider" />
                <div style={{ display:'flex', justifyContent:'space-between', fontWeight:700, fontSize:16, marginBottom:16 }}>
                  <span>Total</span>
                  <span style={{ color:'var(--accent)' }}>₹{total.toFixed(2)}</span>
                </div>
                <div className="form-group">
                  <label className="form-label">Delivery Address</label>
                  <textarea className="form-input" rows={2} placeholder="Enter your delivery address…" value={address} onChange={e => setAddress(e.target.value)} />
                </div>
                <button className="btn btn-primary btn-full" onClick={placeOrder} disabled={placing || !address.trim()}>
                  {placing ? '⏳ Placing…' : `Place Order · ₹${total.toFixed(2)}`}
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function MenuSection({ title, items, localQty, onAdd, onRemove, busy, disabled }) {
  return (
    <div style={{ marginBottom:28 }}>
      <h3 style={{ fontFamily:'var(--display)', fontSize:16, fontWeight:700, color:'var(--text2)', marginBottom:12, paddingBottom:8, borderBottom:'1px solid var(--border)' }}>{title}</h3>
      <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
        {items.map(item => {
          const qty = localQty[item.id] || 0;
          return (
            <div key={item.id} style={{ ...ms.card, opacity: disabled ? 0.5 : 1 }}>
              <div style={ms.body}>
                <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:4 }}>
                  <span style={{ width:10, height:10, borderRadius:'50%', background: item.is_veg ? 'var(--green)' : 'var(--red)', display:'inline-block', flexShrink:0 }} />
                  <span style={ms.name}>{item.name}</span>
                </div>
                {item.description && <p style={ms.desc}>{item.description}</p>}
                <span style={ms.price}>₹{item.price}</span>
              </div>
              <div style={ms.action}>
                {disabled ? null : qty === 0 ? (
                  <button className="btn btn-primary btn-sm" onClick={() => onAdd(item)} disabled={busy}>+ Add</button>
                ) : (
                  <div style={ms.qtyCtrl}>
                    <button style={ms.qtyBtn} onClick={() => onRemove(item.id)} disabled={busy}>−</button>
                    <span style={ms.qty}>{qty}</span>
                    <button style={ms.qtyBtn} onClick={() => onAdd(item)} disabled={busy}>+</button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

const s = {
  header: { position:'relative', borderRadius:'var(--r-xl)', padding:'32px 28px', marginBottom:28, overflow:'hidden' },
  headerBg: { position:'absolute', inset:0, background:'linear-gradient(135deg,var(--navy2),var(--navy3))', borderRadius:'var(--r-xl)' },
  cartPanel: { background:'var(--surface)', border:'1px solid var(--border)', borderRadius:'var(--r-xl)', padding:20, position:'sticky', top:80 },
  cartRow: { display:'flex', alignItems:'center', gap:10 },
  cartName: { flex:1, fontSize:13, fontWeight:500 },
  qtyCtrl: { display:'flex', alignItems:'center', gap:4, background:'var(--navy2)', border:'1px solid var(--border)', borderRadius:'var(--r-sm)', padding:2 },
  qtyBtn: { width:26, height:26, borderRadius:6, background:'var(--surface2)', color:'var(--text)', fontSize:16, display:'flex', alignItems:'center', justifyContent:'center', border:'none', cursor:'pointer' },
};
const ms = {
  card: { display:'flex', alignItems:'center', gap:16, padding:14, background:'var(--surface)', border:'1px solid var(--border)', borderRadius:'var(--r-lg)', transition:'var(--tr)' },
  body: { flex:1 },
  name: { fontWeight:700, fontSize:15 },
  desc: { fontSize:12, color:'var(--muted)', marginTop:2, marginBottom:6 },
  price: { fontWeight:800, color:'var(--accent)', fontSize:15 },
  action: { flexShrink:0 },
  qtyCtrl: { display:'flex', alignItems:'center', gap:4, background:'var(--navy2)', border:'1px solid var(--border2)', borderRadius:'var(--r-sm)', padding:3 },
  qtyBtn: { width:28, height:28, borderRadius:6, background:'var(--surface2)', color:'var(--text)', fontSize:18, display:'flex', alignItems:'center', justifyContent:'center', border:'none', cursor:'pointer' },
  qty: { minWidth:22, textAlign:'center', fontWeight:800, fontSize:14 },
};
