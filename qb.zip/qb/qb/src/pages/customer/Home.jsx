import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { restaurants as restaurantsAPI } from '../../api';
import { useAuth } from '../../context/index.jsx';

export default function CustomerHome() {
  const { user } = useAuth();
  const nav = useNavigate();
  const [list, setList]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [error, setError]   = useState('');

  useEffect(() => {
    restaurantsAPI.list()
      .then(setList)
      .catch(() => setError('Could not load restaurants. Is your backend running?'))
      .finally(() => setLoading(false));
  }, []);

  const filtered = list.filter(r =>
    r.name.toLowerCase().includes(search.toLowerCase()) ||
    r.address.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="page fade-in">
      {/* Greeting */}
      <div style={s.hero}>
        <div style={s.heroBg} />
        <div style={{ position:'relative', zIndex:1 }}>
          <div style={s.tag}>🍽️ Food delivery across your city</div>
          <h1 style={s.heroTitle}>Hey {user?.username}, <span style={{ color:'var(--accent)' }}>hungry?</span></h1>
          <p style={s.heroSub}>Order from approved restaurants and track in real time.</p>
          <input
            style={s.search}
            placeholder="🔍 Search restaurants by name or area..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
      </div>

      {error && <div className="badge badge-red" style={{ marginBottom:20, fontSize:13 }}>{error}</div>}

      <h2 className="section-title">Restaurants near you</h2>

      {loading ? (
        <div className="loading-wrap"><div className="spinner" /><span>Loading restaurants…</span></div>
      ) : filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">{search ? '🔍' : '🏪'}</div>
          <h3>{search ? `No results for "${search}"` : 'No restaurants available'}</h3>
          <p>{search ? 'Try a different search' : 'Check back later'}</p>
        </div>
      ) : (
        <div style={s.grid}>
          {filtered.map(r => (
            <div key={r.id} style={s.card} onClick={() => nav(`/restaurant/${r.id}`)} className="fade-in">
              <div style={s.cardImg}>
                <span style={{ fontSize:60 }}>🍽️</span>
                <span className="badge badge-green" style={{ position:'absolute', top:12, left:12 }}>OPEN</span>
                {!r.is_approved && <span className="badge badge-red" style={{ position:'absolute', top:12, right:12 }}>PENDING</span>}
              </div>
              <div style={s.cardBody}>
                <h3 style={s.restName}>{r.name}</h3>
                <p style={s.restAddr}>📍 {r.address}</p>
                <div style={s.restMeta}>
                  <span>📞 {r.contact_number}</span>
                  <span style={s.viewBtn}>View Menu →</span>
                </div>
                {r.menu?.items?.length > 0 && (
                  <p style={{ fontSize:12, color:'var(--muted)', marginTop:6 }}>
                    {r.menu.items.length} item{r.menu.items.length !== 1 ? 's' : ''} on menu
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

const s = {
  hero: { position:'relative', borderRadius:'var(--r-2xl)', padding:'40px 36px', marginBottom:32, overflow:'hidden' },
  heroBg: { position:'absolute', inset:0, background:'linear-gradient(135deg,var(--navy2) 0%,var(--navy3) 60%,#100d30 100%)', borderRadius:'var(--r-2xl)' },
  tag: { display:'inline-block', background:'rgba(249,115,22,.12)', border:'1px solid rgba(249,115,22,.25)', color:'var(--accent)', borderRadius:20, padding:'4px 14px', fontSize:12, fontWeight:700, marginBottom:16 },
  heroTitle: { fontFamily:'var(--display)', fontSize:'clamp(26px,4vw,46px)', fontWeight:800, marginBottom:10, lineHeight:1.15 },
  heroSub: { color:'var(--muted)', fontSize:15, marginBottom:24 },
  search: { width:'100%', maxWidth:480, padding:'12px 16px', background:'rgba(255,255,255,.06)', border:'1px solid var(--border2)', borderRadius:'var(--r-md)', color:'var(--text)', fontSize:14, outline:'none', backdropFilter:'blur(8px)' },
  grid: { display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))', gap:20 },
  card: { background:'var(--surface)', border:'1px solid var(--border)', borderRadius:'var(--r-xl)', overflow:'hidden', cursor:'pointer', transition:'var(--tr)' },
  cardImg: { height:140, background:'linear-gradient(135deg,var(--navy2),var(--surface2))', display:'flex', alignItems:'center', justifyContent:'center', position:'relative' },
  cardBody: { padding:16 },
  restName: { fontFamily:'var(--display)', fontSize:16, fontWeight:700, marginBottom:4 },
  restAddr: { fontSize:13, color:'var(--muted)', marginBottom:10 },
  restMeta: { display:'flex', justifyContent:'space-between', alignItems:'center', fontSize:12, color:'var(--muted)' },
  viewBtn: { color:'var(--accent)', fontWeight:700, fontSize:13 },
};
