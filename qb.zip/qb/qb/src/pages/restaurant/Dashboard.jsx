import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { restaurants as rAPI, orders as ordersAPI } from '../../api';
import { useToast } from '../../context/index.jsx';

export default function RestaurantDashboard() {
  const nav  = useNavigate();
  const toast = useToast();

  const [restaurant, setRestaurant] = useState(null);
  const [orders, setOrders]         = useState([]);
  const [loading, setLoading]       = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm]             = useState({ name:'', address:'', contact_number:'' });
  const [busy, setBusy]             = useState(false);
  const [updatingOrder, setUpdatingOrder] = useState(null);

  const load = async () => {
    setLoading(true);
    try {
      const r = await rAPI.manage();
      setRestaurant(r);
    } catch (err) {
      if (err?.status === 404) setRestaurant(null); // no restaurant yet
    }
    try {
      const o = await ordersAPI.restaurantOrders(); // fetch orders placed at this restaurant
      setOrders(o);
    } catch {}
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const createRestaurant = async e => {
    e.preventDefault();
    setBusy(true);
    try {
      await rAPI.create(form);
      toast('Restaurant created! Awaiting admin approval.', 'success');
      setShowCreate(false);
      load();
    } catch (err) {
      toast(err?.data?.detail || err?.data?.error || 'Failed to create', 'error');
    } finally { setBusy(false); }
  };

  const updateStatus = async (orderId, status) => {
    setUpdatingOrder(orderId);
    try {
      await ordersAPI.updateStatus(orderId, status);
      toast(`Order #${orderId} → ${status}`, 'success');
      load();
    } catch (err) {
      toast(err?.data?.error || 'Update failed', 'error');
    } finally { setUpdatingOrder(null); }
  };

  // Restaurant only moves PENDING → PREPARING. Delivery handles PICKED_UP → OUT_FOR_DELIVERY → DELIVERED
  const NEXT_STATUS = { PENDING: 'PREPARING' };
  const NEXT_LABEL  = { PENDING: '✅ Accept & Start Preparing' };

  if (loading) return <div className="loading-wrap"><div className="spinner" /></div>;

  return (
    <div className="page fade-in">
      <h1 className="page-title">🏪 Restaurant Dashboard</h1>

      {/* No restaurant yet */}
      {!restaurant && !showCreate && (
        <div className="card" style={{ textAlign:'center', padding:48 }}>
          <div style={{ fontSize:56, marginBottom:16 }}>🏪</div>
          <h2 style={{ fontFamily:'var(--display)', marginBottom:8 }}>You haven't registered a restaurant yet</h2>
          <p style={{ color:'var(--muted)', marginBottom:24 }}>Create your restaurant profile to start receiving orders.</p>
          <button className="btn btn-primary btn-lg" onClick={() => setShowCreate(true)}>+ Register Restaurant</button>
        </div>
      )}

      {/* Create form */}
      {showCreate && (
        <div className="card" style={{ maxWidth:480, marginBottom:28 }}>
          <h2 style={{ fontFamily:'var(--display)', marginBottom:18 }}>Register Your Restaurant</h2>
          <form onSubmit={createRestaurant}>
            <div className="form-group">
              <label className="form-label">Restaurant Name</label>
              <input className="form-input" required value={form.name} onChange={e => setForm(f=>({...f,name:e.target.value}))} placeholder="e.g. Spice Garden" />
            </div>
            <div className="form-group">
              <label className="form-label">Address</label>
              <textarea className="form-input" required rows={2} value={form.address} onChange={e => setForm(f=>({...f,address:e.target.value}))} placeholder="Full restaurant address" />
            </div>
            <div className="form-group">
              <label className="form-label">Contact Number</label>
              <input className="form-input" required value={form.contact_number} onChange={e => setForm(f=>({...f,contact_number:e.target.value}))} placeholder="9876543210" />
            </div>
            <div style={{ display:'flex', gap:10 }}>
              <button className="btn btn-primary" type="submit" disabled={busy}>{busy ? 'Creating…' : 'Create Restaurant'}</button>
              <button className="btn btn-secondary" type="button" onClick={() => setShowCreate(false)}>Cancel</button>
            </div>
          </form>
        </div>
      )}

      {/* Restaurant info */}
      {restaurant && (
        <>
          <div className="card" style={{ marginBottom:24 }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', flexWrap:'wrap', gap:12 }}>
              <div>
                <h2 style={{ fontFamily:'var(--display)', fontSize:22, fontWeight:800, marginBottom:6 }}>{restaurant.name}</h2>
                <p style={{ color:'var(--muted)', fontSize:14, marginBottom:4 }}>📍 {restaurant.address}</p>
                <p style={{ color:'var(--muted)', fontSize:14, marginBottom:12 }}>📞 {restaurant.contact_number}</p>
                <span className={`badge ${restaurant.is_approved ? 'badge-green' : 'badge-yellow'}`}>
                  {restaurant.is_approved ? '✅ Approved & Active' : '⏳ Awaiting Approval'}
                </span>
              </div>
              <div style={{ display:'flex', gap:10 }}>
                <button className="btn btn-secondary btn-sm" onClick={() => nav('/restaurant/menu')}>Manage Menu</button>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid3" style={{ marginBottom:28 }}>
            {[
              ['📦 Total Orders', orders.length, 'var(--teal)'],
              ['⏳ Pending', orders.filter(o => o.status==='PENDING').length, 'var(--yellow)'],
              ['✅ Delivered', orders.filter(o => o.status==='DELIVERED').length, 'var(--green)'],
            ].map(([label, val, color]) => (
              <div key={label} className="card" style={{ textAlign:'center' }}>
                <div style={{ fontFamily:'var(--display)', fontSize:36, fontWeight:800, color }}>{val}</div>
                <div style={{ color:'var(--muted)', fontSize:13, marginTop:4 }}>{label}</div>
              </div>
            ))}
          </div>

          {/* Orders */}
          <h2 className="section-title">Incoming Orders</h2>
          {orders.length === 0 ? (
            <div className="empty-state"><div className="empty-icon">📭</div><h3>No orders yet</h3></div>
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
              {orders.map(order => (
                <div key={order.id} className="card" style={{ padding:'18px 22px' }}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:10 }}>
                    <div>
                      <span style={{ fontFamily:'var(--display)', fontWeight:700 }}>Order #{order.id}</span>
                      <span style={{ color:'var(--muted)', fontSize:13, marginLeft:12 }}>{new Date(order.created_at).toLocaleString('en-IN')}</span>
                    </div>
                    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                      <span className={`badge status-${order.status}`} style={{ padding:'4px 12px', borderRadius:20, fontSize:12, fontWeight:700 }}>{order.status}</span>
                      <span style={{ fontWeight:700, color:'var(--accent)' }}>₹{order.total_amount}</span>
                    </div>
                  </div>
                  <div style={{ marginTop:10, display:'flex', flexWrap:'wrap', gap:6 }}>
                    {order.items?.map((it, i) => (
                      <span key={i} style={{ padding:'2px 10px', background:'var(--navy2)', border:'1px solid var(--border)', borderRadius:20, fontSize:12, color:'var(--text2)' }}>
                        {it.quantity}× {it.menu_item_name}
                      </span>
                    ))}
                  </div>
                  <div style={{ fontSize:13, color:'var(--muted)', marginTop:8 }}>📍 {order.delivery_address}</div>
                  {NEXT_STATUS[order.status] && (
                    <button className="btn btn-primary btn-sm" style={{ marginTop:12 }}
                      disabled={updatingOrder === order.id}
                      onClick={() => updateStatus(order.id, NEXT_STATUS[order.status])}>
                      {updatingOrder === order.id ? '⏳ Updating…' : NEXT_LABEL[order.status]}
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
